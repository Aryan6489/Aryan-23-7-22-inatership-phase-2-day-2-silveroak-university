
function myFunction()
 {
   var txt=document.getElementnyid("my Text");
   alert(txt.value);    
}

funtion myAlert(msg) {
    if(confirm("Are you sure you to display the message????")){
        alert(msg);
    }
    esle{
         alert("message not displayed as user canceled opertion");
    }
}
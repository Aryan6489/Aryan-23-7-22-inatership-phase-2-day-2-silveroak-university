
    function myFunction() {
        a=document.getElementsByTagName("input")
        alert(a[0].value);
        alert(a(1).value);
    }